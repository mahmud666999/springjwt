package com.example.springjwt;

import lombok.Data;

@Data
public class RegisterDTO {
    public String username;
    public String password;
}
