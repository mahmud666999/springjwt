package com.example.springjwt;

import jakarta.persistence.*;

@Entity
public class Feedback {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "feedback_id_generator")
    @SequenceGenerator(name="feedback_id_generator", sequenceName = "feedback_id_generator", allocationSize=1,initialValue = 21)
    @Column(name = "id")
    private int id;
    private String feedback;


}
