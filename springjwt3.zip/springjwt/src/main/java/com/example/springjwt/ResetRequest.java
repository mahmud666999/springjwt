package com.example.springjwt;


import jakarta.persistence.*;

@Entity
public class ResetRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "reset_id_generator")
    @SequenceGenerator(name="reset_id_generator", sequenceName = "reset_id_generator", allocationSize=1)
    private int id;

    private String firstname;
    private String email;
    private String username;
    private String password;

}
